import pydicom
import numpy
import matplotlib.pyplot as plt

## File structure

#Test file

file="000000.dcm"

image=pydicom.dcmread(file)


plt.imsave(arr=image.pixel_array, fname='converted' + "\\Malignant\\" + 'file1'
                                                                         + "_" + str(image.Laterality) + ".jpg",
           cmap=plt.cm.gray)
